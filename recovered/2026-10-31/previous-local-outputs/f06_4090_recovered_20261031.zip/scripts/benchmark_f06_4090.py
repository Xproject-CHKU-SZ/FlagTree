"""F06 eager decomposition vs torch.compile/Inductor, CUDA inference only.

Requires PyTorch 2.x with CUDA and a working Inductor/Triton installation.
Run: python3 scripts/benchmark_f06_4090.py --output f06_4090
Compilation is excluded from timing. Compiled does not imply single-kernel fusion.
"""
import argparse
import csv
import json
import statistics
import time
from pathlib import Path

import torch


def operation(name, x, residual, weight, bias):
    acc = torch.float64 if x.dtype == torch.float64 else torch.float32
    if name.startswith('matmul'):
        y = x @ weight + bias
        if name.endswith('relu'):
            y = torch.relu(y)
        elif name.endswith('gelu'):
            y = torch.nn.functional.gelu(y, approximate='tanh')
        elif name.endswith('silu'):
            y = torch.nn.functional.silu(y)
        return y
    y = x + residual if name.startswith('residual') else x
    if 'layernorm' in name:
        z = y.to(acc)
        mean = z.mean(-1, keepdim=True)
        var = ((z - mean) ** 2).mean(-1, keepdim=True)
        return ((z - mean) * torch.rsqrt(var + 1e-5) * weight.to(acc) + bias.to(acc)).to(x.dtype)
    if 'rmsnorm' in name:
        z = y.to(acc)
        return (z * torch.rsqrt((z * z).mean(-1, keepdim=True) + 1e-5) * weight.to(acc)).to(x.dtype)
    if 'softmax' in name:
        z = x.to(acc) * 0.125
        if 'bias' in name:
            z = z + bias.to(acc)
        if 'mask' in name:
            # Broadcast mask, always at least one valid entry per row.
            mask = torch.arange(x.shape[-1], device=x.device) < (x.shape[-1] * 3 // 4)
            z = z.masked_fill(~mask, float('-inf'))
        e = torch.exp(z - z.amax(-1, keepdim=True))
        return (e / e.sum(-1, keepdim=True)).to(x.dtype)
    z = x.to(acc)
    if name == 'square_sum':
        return (z * z).sum(-1)
    if name == 'mean_variance':
        mean = z.mean(-1, keepdim=True)
        return torch.cat((mean, ((z - mean) ** 2).mean(-1, keepdim=True)), -1)
    if name == 'l2_normalize':
        return (z * torch.rsqrt((z * z).sum(-1, keepdim=True) + 1e-5)).to(x.dtype)
    if name == 'dot_reduce':
        return (z * residual.to(acc)).sum(-1)
    raise ValueError(name)


CASES = ['matmul_bias', 'matmul_bias_relu', 'matmul_bias_gelu', 'matmul_bias_silu',
         'layernorm', 'residual_layernorm', 'rmsnorm', 'residual_rmsnorm',
         'scale_softmax', 'scale_bias_softmax', 'scale_mask_softmax',
         'scale_bias_mask_softmax', 'square_sum', 'mean_variance',
         'l2_normalize', 'dot_reduce']


def latency(fn, warmup, repeats, iterations):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    samples = []
    for _ in range(repeats):
        start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(iterations):
            fn()
        end.record()
        end.synchronize()
        samples.append(start.elapsed_time(end) * 1000 / iterations)
    return samples


def kernels(fn):
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                            torch.profiler.ProfilerActivity.CUDA]) as p:
        fn()
        torch.cuda.synchronize()
    return sum(e.device_type == torch.autograd.DeviceType.CUDA for e in p.events())


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='f06_4090')
    parser.add_argument('--cases', nargs='+', choices=CASES, default=CASES)
    parser.add_argument('--dtypes', nargs='+', choices=['float32', 'float16', 'bfloat16'],
                        default=['float32', 'float16', 'bfloat16'])
    parser.add_argument('--shapes', nargs='+', default=['1,128,128', '32,768,768', '256,1024,1024'])
    parser.add_argument('--warmup', type=int, default=20)
    parser.add_argument('--repeats', type=int, default=7)
    parser.add_argument('--iterations', type=int, default=100)
    parser.add_argument('--allow-other-gpu', action='store_true')
    args = parser.parse_args()
    if min(args.warmup, args.repeats, args.iterations) < 1:
        parser.error('timing counts must be positive')
    if not torch.cuda.is_available():
        parser.error('CUDA is unavailable')
    gpu = torch.cuda.get_device_name()
    if '4090' not in gpu and not args.allow_other_gpu:
        parser.error(f'Expected 4090, found {gpu}; use --allow-other-gpu to override')
    torch.manual_seed(2026)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    metadata = dict(gpu=gpu, torch=torch.__version__, cuda=torch.version.cuda,
                    seed=2026, tf32=False, args=vars(args),
                    baseline='eager explicit decomposition', candidate='torch.compile Inductor fullgraph',
                    timing='CUDA event median, compilation excluded, no CUDA graphs',
                    dynamic='static specializations over batch/width sweep; not dynamic graph validation')
    (output / 'environment.json').write_text(json.dumps(metadata, indent=2))
    rows = []
    for dtype_name in args.dtypes:
        dtype = getattr(torch, dtype_name)
        for shape in args.shapes:
            m, k, n = map(int, shape.split(','))
            if min(m, k, n) < 1:
                parser.error('shape dimensions must be positive')
            for name in args.cases:
                row = dict(case=name, dtype=dtype_name, m=m, k=k, n=n)
                try:
                    x = torch.randn(m, k, device='cuda', dtype=dtype) * 0.2
                    residual = torch.randn_like(x) * 0.2
                    weight = torch.randn((k, n) if name.startswith('matmul') else (k,), device='cuda', dtype=dtype) * 0.2
                    bias = torch.randn(n if name.startswith('matmul') else k, device='cuda', dtype=dtype) * 0.2
                    inputs = (x, residual, weight, bias)
                    eager = lambda: operation(name, *inputs)
                    compiled = torch.compile(lambda a, b, c, d: operation(name, a, b, c, d),
                                             backend='inductor', fullgraph=True, dynamic=False)
                    candidate = lambda: compiled(*inputs)
                    t0 = time.perf_counter()
                    actual = candidate()
                    torch.cuda.synchronize()
                    row['compile_first_call_s'] = time.perf_counter() - t0
                    expected = eager()
                    # Independent float64 oracle, casting outputs only after comparison.
                    reference = operation(name, *(t.double() for t in inputs))
                    a, b = actual.double(), expected.double()
                    diff = (a - b).abs()
                    atol, rtol = (1e-4, 1e-4) if dtype == torch.float32 else ((0.02, 0.02) if dtype == torch.bfloat16 else (0.002, 0.002))
                    row.update(max_abs_error=diff.max().item(),
                               max_rel_error=(diff / b.abs().clamp_min(1e-8)).max().item(),
                               rmse=diff.square().mean().sqrt().item(),
                               candidate_reference_max_abs=(a-reference.double()).abs().max().item(),
                               atol=atol, rtol=rtol,
                               accuracy_pass=bool(torch.isfinite(a).all() and torch.allclose(a, b, atol=atol, rtol=rtol)))
                    # Alternate A/B ordering to reduce systematic order bias.
                    samples = {'eager': [], 'compiled': []}
                    for r in range(args.repeats):
                        order = [('eager', eager), ('compiled', candidate)]
                        for label, fn in order[::1 if r % 2 == 0 else -1]:
                            samples[label] += latency(fn, args.warmup, 1, args.iterations)
                    before, after = map(statistics.median, (samples['eager'], samples['compiled']))
                    row.update(before_us=before, after_us=after, speedup=before/after,
                               eager_samples_us=samples['eager'], compiled_samples_us=samples['compiled'],
                               eager_kernels=kernels(eager), compiled_kernels=kernels(candidate), status='ok')
                except Exception as exc:
                    row.update(status='error', error=f'{type(exc).__name__}: {exc}')
                rows.append(row)
                print(json.dumps(row), flush=True)
                (output / 'results.json').write_text(json.dumps(rows, indent=2))
                fields = list(dict.fromkeys(key for item in rows for key in item))
                with (output / 'results.csv').open('w', newline='') as f:
                    writer = csv.DictWriter(f, fieldnames=fields)
                    writer.writeheader()
                    writer.writerows(rows)
                torch._dynamo.reset()
    if any(r['status'] != 'ok' or not r.get('accuracy_pass', False) for r in rows):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
